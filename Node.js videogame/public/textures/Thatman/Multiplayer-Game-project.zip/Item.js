const Sprite = require("./Sprite.js");
const MAX_INVENTORY = 4;

class Item extends Sprite{
	constructor(x,y,w,h,textureID,name){
		super(x,y,w,h,textureID);
		this.uses = 0;
	}

	update(players){		
		for (let i = 0; i < players.length; i++){
			if (this.touching(players[i].sprite)){
				if (players[i].inventory.length < MAX_INVENTORY){
					players[i].collect(this);
					return true;
				}
			}			
		}

		return false;
	}

	use(){
		//Empty
	}
}

//***** GUN
const GUN_USES = 5;

class Gun extends Item{
	constructor(x,y,w,h,textureID,name){
		super(x,y,w,h,textureID,name);

		this.uses = GUN_USES;
	}

	use(player){
		player.fire();
		this.uses--;
		if (this.uses == 0)
			return true;
		return false;
	}
}


//***** MEDKIT
const MEDKIT_USES = 1;
const HEALTH_BOOST = 15;

class MedKit extends Item{
	constructor(x,y,w,h,textureID,name){
		super(x,y,w,h,textureID,name);

		this.uses = MEDKIT_USES;
	}

	use(player){
		player.health += HEALTH_BOOST;
		
		this.uses--;
		if (this.uses == 0)
			return true;
		return false;
	}
}

module.exports = {
	Gun,
	MedKit
};
