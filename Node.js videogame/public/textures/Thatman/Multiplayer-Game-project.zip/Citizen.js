const Entity = require("./Entity.js");


const CITIZEN_SPEED = 1;

//the time it takes for a citizen to want to change directions
const CHANGE_DIR = 150;
const MIN_ATTACK_DISTANCE = 50;

class Citizen extends Entity{
	constructor(x,y,textureStartIndex){
		super(x,y,textureStartIndex);
		this.speed = CITIZEN_SPEED;
		this.index = textureStartIndex;

		//the direction this citizen is moving, or whether he moves at all
		this.action = 0;
		this.timer = 0;

		//the player this citizen is targetting
		this.target = null;
	}

	update(players,criminals){
		if (this.updateEntity == false)
			return;
		
		super.update();

		if (this.dead) return;

		this.checkForCriminalHit(criminals);
		this.checkForPlayerHit(players);
		
		//walking AI
		if (this.target == null){
			this.walk();
		} 
		//fighting AI
		else{
			this.attackTarget();
		}

		this.updateEntity = false;
	}

	walk(){
		if (this.takingDamage) return;
		
		//change directions randomly 
		this.walking = false;

		this.timer--;
		if (this.timer <= 0){
			this.timer = CHANGE_DIR;
			//reset the direction
			this.action = Math.floor(Math.random() * 10);
		}

		switch(this.action){
			case 0:
				this.direction = this.action;
				this.sprite.x += CITIZEN_SPEED;
				this.walking = true;
				break;
			case 1:
				this.direction = this.action;
				this.sprite.y -= CITIZEN_SPEED;
				this.walking = true;
				break;
			case 2:
				this.direction = this.action;
				this.sprite.x -= CITIZEN_SPEED;
				this.walking = true;
				break;
			case 3:
				this.direction = this.action;
				this.sprite.y += CITIZEN_SPEED;
				this.walking = true;
				break;				
		}
	}

	attackTarget(){
		if (this.target.dead == true){
			this.target = null;
			this.punching = false;

			return;
		}
		
		let xDist = this.target.sprite.x - this.sprite.x;
		let yDist = this.target.sprite.y - this.sprite.y;

		let distance = Math.sqrt(Math.pow(xDist,2) + Math.pow(yDist,2));
	
		if (distance <= MIN_ATTACK_DISTANCE){
			this.punching = true;
			//make the AI face the player
			this.moveInDirection(xDist,yDist,1,false);
			
			return;
		}
		this.punching = false;

		//move towards the target in the X axis
		this.moveInDirection(xDist,yDist,1,true);		
	}

	checkForPlayerHit(players){
		let attacker = this.checkForAttack(players);
		if (attacker != null)
			this.target = attacker;
	}
	checkForCriminalHit(criminals){
		let attacker = this.checkForAttack(criminals);
		if (attacker != null)
			this.target = attacker;
	}

}

module.exports = Citizen;