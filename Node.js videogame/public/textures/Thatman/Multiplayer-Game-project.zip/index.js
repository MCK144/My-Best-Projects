//************ SERVER METHODS ****************

var express = require("express");
//create the appliction
var app = express();
//create the server
var server = app.listen(5000);
//serve the 'public' folder 
app.use(express.static("public"));
var socket = require("socket.io");
io = socket(server);
console.log("***********server start ***************");

//************** GAME START **********************

const WORLD_W = 4000; //10000
const WORLD_H = 2000; // 10000
const CLIENT_SCREEN_WIDTH = 900;
const CLIENT_SCREEN_HEIGHT = 600;

const Sprite = require("./Sprite.js");
const Player = require("./Player.js");
const Citizen = require("./Citizen.js");
const {Gun,MedKit} = require("./Item.js");
const BulletManager = require("./BulletManager.js");
const Criminal = require("./Criminal.js");

var bulletManager = new BulletManager;

var numPlayers = 0;
var players = [];

var citizens = [];
var streets = [];
var items = [];
var criminals = [];

//holds all the data to go to the client
var serverData = [];


createStreets();
createCitizens();
createItems();
createCriminals();

//player setup
io.sockets.on("connection",function(client){
	console.log("New connection: " + client.id);

	// spawn a new player
	var player = new Player(100,100,numPlayers,client.id,bulletManager);
	players[numPlayers++] = player;

	let gun = new Gun(0,0,0,0,82,"gun");
	player.collect(gun);
	
	//broadcast the play index back to the client so it knows'
	//which player it owns
	client.emit("getPlayerIndex",numPlayers - 1);

	//upload all the static data (streets) to the player once
	client.emit("getStaticData",streets);

	// update the client key state
	client.on("keyUpdate",function(keys){
		player.keys = keys;
	});

	client.on("playerClick",function(data){
		player.click = true;
		data[0] += player.sprite.x + player.sprite.w / 2;
		data[1] += player.sprite.y + player.sprite.h / 2;
		player.mousePos = data;
	});
	
	client.on("disconnect", function(){
		//update the player indicies for all other players
		io.sockets.emit("updatePlayerIndex",player.index);
		
		//delete the player
		players.splice(player.index,1);
		numPlayers--;
	});
	
	
});

function serverUpdate(){
	//optimize the server, only update the NPCs that are close to a player
	checkPlayerProximity(citizens,players,criminals);
	
	//update the bullets
	bulletManager.update(citizens,players,criminals);
	
	//update the players
	for (let i = 0; i < numPlayers; i++){
		players[i].update(citizens,criminals);
	}

	//update the citizens
	for (let i = 0; i < citizens.length; i++){
		citizens[i].update(players,criminals);
	}
	
	//update the items
	for (let i = 0; i < items.length; i++){
		if (items[i].update(players)){
			items.splice(i,1);
		};
	}

	//update the criminals
	for (let i = 0; i < criminals.length; i++){
		criminals[i].update(players,citizens);
	}
	
	//reset the server data 
	serverData[0] = citizens;
	serverData[1] = players;
	serverData[2] = items;
	serverData[3] = bulletManager.bullets;
	serverData[4] = criminals;

	
	io.sockets.emit("serverUpdate",serverData);
}

function createStreets(){
	//create the streets 
	const NUM_STREETS_HORIZONTAL = 3;
	const HORIZONTAL_PIECES = 6;
	const NUM_STREETS_VERTICAL = 4;
	const VERTICAL_PIECES = 3;
	
	const STREET_WIDTH = 100;
	
	let verticalPadding = WORLD_H / (NUM_STREETS_HORIZONTAL + 1);
	let streetLength = WORLD_W / HORIZONTAL_PIECES;
	
	let horizontalPadding = WORLD_W / (NUM_STREETS_VERTICAL + 1);
	let streetHeight = WORLD_H / VERTICAL_PIECES;
	
	for (let i = 1; i <= NUM_STREETS_HORIZONTAL; i++){
		for (let j = 0; j < HORIZONTAL_PIECES; j++){
			let y = (verticalPadding - STREET_WIDTH / 2) * i;
			let x = j * streetLength;
			let w = streetLength;
			let h = STREET_WIDTH;
	
			//create the street
			let newStreet = new Sprite(x,y,w,h,80);
			streets[streets.length] = newStreet;
		}
	}
	
	for (let i = 1; i <= NUM_STREETS_VERTICAL; i++){
		for (let j = 0; j < VERTICAL_PIECES; j++){
			let x = (horizontalPadding - STREET_WIDTH / 2) * i;
			let y = j * streetHeight;
			let w = STREET_WIDTH;
			let h = streetHeight;
	
			//create the street
			let newStreet = new Sprite(x,y,w,h,81);
			streets[streets.length] = newStreet;
		}
	}
}

function createCitizens(){
	const NUM_CITIZENS = 100;
	
	for (let i = 0; i < NUM_CITIZENS; i++){
		let randX = Math.floor(Math.random() * WORLD_W);
		let randY = Math.floor(Math.random() * WORLD_H);
		let newCitizen = new Citizen(randX,randY,0);
		citizens[citizens.length] = newCitizen;
	}

	serverData[serverData.length] = citizens;
}

function createItems(){
	const NUM_ITEMS = 20;
	
	const ITEM_WIDTH = 15;
	const ITEM_HEIGHT = 15;
	
	for (let i = 0; i < NUM_ITEMS; i++){
		let randX = Math.floor(Math.random() * WORLD_W);
		let randY = Math.floor(Math.random() * WORLD_H); 

		let pick = Math.floor(Math.random() * 2);
		//spawn gun
		if (pick == 0){
			items[items.length] = new Gun(randX,randY,ITEM_WIDTH,ITEM_HEIGHT,82,"gun");
		}
		//medkit
		else{
			items[items.length] = new MedKit(randX,randY,ITEM_WIDTH,ITEM_HEIGHT,83,"medkit");
		}

	}

	serverData[serverData.length] = items;
}

function createCriminals(){
	const NUM_CRIMINALS = 25;
	
	for (let i = 0; i < NUM_CRIMINALS; i++){
		let randX = Math.floor(Math.random() * WORLD_W);
		let randY = Math.floor(Math.random() * WORLD_H);
		let threatLevel = Math.floor(Math.random() * 4 + 1);
		let crook = new Criminal(randX,randY,0,threatLevel);
		
		criminals[criminals.length] = crook;
	}

	serverData[serverData.length] = criminals;
}

function checkPlayerProximity(citizens,players,criminals){
	for (let i = 0; i < players.length; i++){
		let player = players[i];
		for (let j = 0; j < citizens.length; j++){
			if (isNear(player,citizens[j]))
				citizens[j].updateEntity = true;
		}
		for (let j = 0; j < criminals.length; j++){
			if (isNear(player,criminals[j]))
				criminals[j].updateEntity = true;
		}
	}
}

function isNear(a,b){
	let xDist = Math.abs(a.sprite.x - b.sprite.x);
	let yDist = Math.abs(a.sprite.y - b.sprite.y);

	if (xDist <= CLIENT_SCREEN_WIDTH/2 && yDist <= CLIENT_SCREEN_HEIGHT/2){
		return true;
	}
	return false;
}

setInterval(serverUpdate,1000/60);

//OPTIMIZATION IDEAS
//1- static data (streets, buildings) should only be uploaded to the client once
//2- only update the objects near a player
//3- stop using players,citizens lists, just use the server data list
//		serverData[1][0].update() instead of players[0].update
// 		note: no server improvement
//4- for everything other than the players, only have the server upload the sprites
//5 - criminals only reset their target players/citizens every 100 frames instead of every frame