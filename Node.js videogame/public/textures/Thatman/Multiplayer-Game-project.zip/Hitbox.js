//the most basic rendering structure

class Hitbox{
	constructor(x,y,w,h,color){
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.color = color;

		//useful for collision detection
		this.active = false;
	}

	touching(hitbox){
		let xDist = Math.abs(this.x - hitbox.x);
		let yDist = Math.abs(this.y - hitbox.y);
		if (xDist <= hitbox.w / 2 + this.w/2 && yDist <= hitbox.h/2 + this.h/2){
			return true;
		}
		return false;
	}
	
}

module.exports = Hitbox;