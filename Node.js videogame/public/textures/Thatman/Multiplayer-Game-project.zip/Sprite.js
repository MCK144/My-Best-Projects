const Hitbox = require("./Hitbox.js");

//the most basic rendering structure
class Sprite extends Hitbox{
	constructor(x,y,w,h,textureID/*, path = "none"*/){
		super(x,y,w,h,"blue");
		this.textureID = textureID;

		/*this.image = null;
		if (path != "none"){
			this.image = new Image;
			this.image.src = path;
		}*/
	}
}

module.exports = Sprite;