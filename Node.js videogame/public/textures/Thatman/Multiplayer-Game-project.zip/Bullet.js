const RADIUS = 5;
const LIFETIME = 30;
const SPEED = 20;
const DAMAGE = 100;

class Bullet {
	constructor(x,y,direction,owner){
		this.x = x;
		this.y = y;
		this.r = RADIUS;
		this.direction = direction;

		this.owner = owner; //the index of the player that shoots this bullet
		this.damage = DAMAGE;
		this.lifetime = LIFETIME;
		this.speed = SPEED;
	}

	update(){
		this.lifetime--;
		if (this.lifetime <= 0)
			return true;

		this.x += this.direction[0] * this.speed;
		this.y += this.direction[1] * this.speed;

		return false;
	}
}

module.exports = Bullet;