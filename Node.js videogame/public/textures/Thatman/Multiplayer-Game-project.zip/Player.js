const Entity = require("./Entity.js");


const PLAYER_SPEED = 3;
const ATTACK_DAMAGE = 10;

class Player extends Entity{
	constructor(x,y,index,id,bulletManager){
		//game data
		super(x,y,0);
		this.speed = PLAYER_SPEED;
		this.attackDamage = ATTACK_DAMAGE;

		
		this.inventory = [];
		this.selectedItem = 0;
		this.bulletManager = bulletManager;
		
		//player keyboard data
		this.index = index;
		this.id = id;
		this.keys = {
			w:false,
			a:false,
			s:false,
			d:false,
			space:false,
			one: false,
			two: false,
			three: false,
			four: false
		};
		//player mouse click
		this.click = false;
		this.mousePos = [0,0];
	}

	update(citizens,criminals){
		super.update();

		if (this.dead) return;

		this.updateInventory();
		this.movePlayer();
		
		this.checkForAttack(citizens);
		this.checkForAttack(criminals);
	}

	updateInventory(){		
		//inventory selection
		if (this.keys['one'] && this.inventory.length > 0){
			this.selectedItem = 0;
		}
		else if (this.keys["two"] && this.inventory.length > 1){
			this.selectedItem = 1;
		}
		else if (this.keys["three"] && this.inventory.length > 2){
			this.selectedItem = 2;
		}
		else if (this.keys["four"] && this.inventory.length > 3){
			this.selectedItem = 3;
		}

		//use item on click
		if (this.click && this.inventory.length > 0){
			if (this.inventory[this.selectedItem].use(this)){
				this.inventory.splice(this.selectedItem,1);
				this.selectedItem--;
				if (this.selectedItem < 0)
					this.selectedItem = 0;
			}
		}

		this.click = false;
	}

	fire(){
		let startX = this.sprite.x + this.sprite.w / 2;
		let startY = this.sprite.y + this.sprite.h / 2;

		//calculate the distance vector
		let dir = [0,0];
		dir[0] = this.mousePos[0] - startX;
		dir[1] = this.mousePos[1] - startY;

		//normalize the distance vector
		let distance = Math.sqrt(Math.pow(dir[0],2) + Math.pow(dir[1],2));
		if (distance == 0) return;
		dir[0] /= distance;
		dir[1] /= distance;
		
		this.bulletManager.spawnBullet(startX,startY,dir,this.index);
	}
	
	movePlayer(){
		this.walking = false;
		this.punching = false;
		
		if (this.keys['w']){
			this.sprite.y += -this.speed;
			this.walking = true;
			this.direction = 1;
		}
		if (this.keys['a']){
			this.sprite.x += -this.speed;
			this.walking = true;
			this.direction = 2;
		}
		if (this.keys['s']){
			this.sprite.y += this.speed;
			this.walking = true;
			this.direction = 3;
		}
		if (this.keys['d']){
			this.sprite.x += this.speed;
			this.walking = true;
			this.direction = 0;
		}
		if (this.keys["space"]){
			this.punching = true;
		}
	}
	
	setAnimationProperties(){
		super.setAnimationProperties();

		//all the player's setAnimationProperties function does is swap the punch animation
		// with the bat animation
		const BAT_TIME = 4;		
		switch(this.animationState){
			case this.animationStates["PUNCH_R"]:
				this.numFrames = 5;
				this.animationTime = BAT_TIME;
				this.startFrame = this.startIndex + 44;
				break;
			case this.animationStates["PUNCH_U"]:
				this.numFrames = 5;
				this.animationTime = BAT_TIME;
				this.startFrame = this.startIndex + 54;
				break;
			case this.animationStates["PUNCH_L"]:
				this.numFrames = 5;
				this.animationTime = BAT_TIME;
				this.startFrame = this.startIndex + 49;
				break;
			case this.animationStates["PUNCH_D"]:
				this.numFrames = 5;
				this.animationTime = BAT_TIME;
				this.startFrame = this.startIndex + 59;
				break;
		}
	}

	collect(item){
		this.inventory[this.inventory.length] = item;
		this.selectedItem = this.inventory.length - 1;
	}
}

module.exports = Player;