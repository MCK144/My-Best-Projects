const Bullet = require("./Bullet.js");


class BulletManager {
	constructor(){
		this.bullets = [];
	}

	//target and start positions (tp, sp) used to calculate the direction of the bullet
	spawnBullet(x,y,direction,playerIndex){
		
		let bullet = new Bullet(x,y,direction,playerIndex);
		this.bullets[this.bullets.length] = bullet;
	}

	update(citizens,players,criminals){
		//move the bullet
		for (let i = 0; i < this.bullets.length; i++){
			//check for collision with citizens
			for (let j = 0; j < citizens.length; j++){
				if (citizens[j].dead || !citizens[j].updateEntity)
					continue;
				if (this.checkCollision(this.bullets[i],citizens[j]))
					break;
			}

			//check for collision with criminals
			for (let j = 0; j < criminals.length; j++){
				if (criminals[j].dead || !criminals[j].updateEntity)
					continue;
				if (this.checkCollision(this.bullets[i],criminals[j]))
					break;
			}

			//update the bullet
			if (this.bullets[i].update()){
				this.bullets.splice(i,1);
				i--;
			}
		}
	}

	checkCollision(bullet,entity){
		
		//box-circle collision adapted from this site, with my own modification
		// https://www.jeffreythompson.org/collision-detection/circle-rect.php	
 		let box = entity.sprite;

		let testX = null;
		let testY = null;
		
		if (bullet.x < box.x)
			testX = box.x;
		else if (bullet.x > box.x + box.w)
			testX = box.x + box.w;
		if (bullet.y < box.y)
			testY = box.y;
		else if (bullet.y > box.y + box.h)
			testY = box.y + box.h;
		
		//calculate the distance
		let xDist = 0;
		let yDist = 0;
		
		if (testX != null)
			xDist = bullet.x - testX;
		if (testY != null)
			yDist = bullet.y - testY;

		let dist = Math.sqrt(Math.pow(xDist,2) + Math.pow(yDist,2));
		
		if (dist <= bullet.r){
			//destroy the bullet
			bullet.lifetime = 0;
			//damage the entity
			entity.takeShot(bullet.damage);
			return true;
		}

		return false;
	}
}

module.exports = BulletManager;