const Sprite = require("./Sprite.js");
const Hitbox = require("./Hitbox.js");

const WIDTH = 20;
const HEIGHT = 60;

const ATTACK_WIDTH = 30;
const ATTACK_HEIGHT = 30;

const START_HEALTH = 100;
const DEFAULT_DAMAGE = 5;
const DAMAGE_COOLDOWN = 30;
const INVULNERABILITY_TIME = 20;


class Entity{
	constructor(x,y,startIndex){
		this.animationStates= {
			IDLE : 0,
			WALKING_R: 1,
			WALKING_U: 2,
			WALKING_L: 3,
			WALKING_D: 4,
			PUNCH_R: 5,
			PUNCH_U: 6,
			PUNCH_L: 7,
			PUNCH_D: 8,
			TAKE_DAMAGE_L: 9,
			TAKE_DAMAGE_U: 10,
			TAKE_DAMAGE_R: 11,
			TAKE_DAMAGE_D: 12,
			DEAD: 13
		}
		
		// turned on if the entity is near a player
		// the server turns this on
		this.updateEntity = false; 


		//***game data***
		this.sprite = new Sprite(x,y,WIDTH,HEIGHT,0);
		this.attackBox = new Hitbox(0,0,ATTACK_WIDTH,ATTACK_HEIGHT,"red");
		this.speed = 0;
		this.walking = false;
		this.punching = false;
		this.health = START_HEALTH;
		this.dead = false;

		//damage
		this.attackDamage = DEFAULT_DAMAGE;
		this.takingDamage = false;
		this.damageTimer = 0; //time before the entity can attack again
		this.invulnerability = 0; //time before the entity can take damage again
		this.direction = 1;

		//***animation data***
		this.prevAnimationState = this.animationStates["IDLE"];
		this.animationState = this.animationStates["IDLE"];
		this.startIndex = startIndex; //where in the list this entity's textures are
		this.time = 0; //the time the current animation has been running
		this.animationTime = 0; //the time each frame of an animation lastsm
		this.numFrames = 0; // the amount of frames in an animation
		this.currFrame = 0;
	}

	update(){
		this.setAnimation();
		if (this.dead){
			this.punching = false;
			this.attackBox.active = false;
			return;
		}

		this.updateAttackBox();
		this.updateDamage();
		
	}

	//update the animation frames
	setAnimation(){
		//***this function must be defined by the child class***
		this.setAnimationProperties();

		if (this.animationState != this.prevAnimationState){
			this.time = 0;
			this.currFrame = 0;
		} 
		else{
			this.time++;
			if (this.time >= this.animationTime){
				this.time = 0;
				this.currFrame = (this.currFrame + 1) % this.numFrames;
			}
		}
		
		this.sprite.textureID = this.currFrame + this.startFrame;
		this.prevAnimationState = this.animationState;
	}
	
	//determine which animation frames are being played
	setAnimationProperties(){
		//NOTE: default animations are stored here
		
		//dead animation
		if (this.dead){
			this.animationState = this.animationStates["DEAD"];
		}
		//taking damage
		else if (this.takingDamage){
			if (this.direction == 0)
				this.animationState = this.animationStates["TAKE_DAMAGE_R"];
			else if (this.direction == 1)
				this.animationState = this.animationStates["TAKE_DAMAGE_U"];
			else if (this.direction == 2)
				this.animationState = this.animationStates["TAKE_DAMAGE_L"];
			else if (this.direction == 3)
				this.animationState = this.animationStates["TAKE_DAMAGE_D"];
		}
		//punching
		else if (this.punching){
			if (this.direction == 0)
				this.animationState = this.animationStates["PUNCH_R"];
			if (this.direction == 1)
				this.animationState = this.animationStates["PUNCH_U"];
			if (this.direction == 2)
				this.animationState = this.animationStates["PUNCH_L"];
			if (this.direction == 3)
				this.animationState = this.animationStates["PUNCH_D"];
		}
		//walking animation
		else if (this.walking){
			if (this.direction == 0)
				this.animationState = this.animationStates["WALKING_R"];
			if (this.direction == 1)
				this.animationState = this.animationStates["WALKING_U"];
			if (this.direction == 2)
				this.animationState = this.animationStates["WALKING_L"];
			if (this.direction == 3)
				this.animationState = this.animationStates["WALKING_D"];
		}
		//idle animation
		else{
			this.animationState = this.animationStates["IDLE"];
		}
		
		const WALK_TIME = 12;
		const PUNCH_TIME = 4;
		const DAMAGE_TIME = 10;
		
		switch(this.animationState){
			case this.animationStates["DEAD"]:
				this.numFrames = 1;
				this.animationTime = 10000;
				this.startFrame = this.startIndex + 68;
				break;
			case this.animationStates["TAKE_DAMAGE_R"]:
				this.numFrames = 1;
				this.animationTime = DAMAGE_TIME;
				this.startFrame = this.startIndex + 65;
				break;
			case this.animationStates["TAKE_DAMAGE_U"]:
				this.numFrames = 1;
				this.animationTime = DAMAGE_TIME;
				this.startFrame = this.startIndex + 67;
				break;
			case this.animationStates["TAKE_DAMAGE_L"]:
				this.numFrames = 1;
				this.animationTime = DAMAGE_TIME;
				this.startFrame = this.startIndex + 64;
				break;
			case this.animationStates["TAKE_DAMAGE_D"]:
				this.numFrames = 1;
				this.animationTime = DAMAGE_TIME;
				this.startFrame = this.startIndex + 66;
				break;
			case this.animationStates["WALKING_R"]:
				this.numFrames = 6;
				this.animationTime = WALK_TIME;
				this.startFrame = this.startIndex + 1;
				break;
			case this.animationStates["WALKING_U"]:
				this.numFrames = 6;
				this.animationTime = WALK_TIME;
				this.startFrame = this.startIndex + 22;
				break;
			case this.animationStates["WALKING_L"]:
				this.numFrames = 6;
				this.animationTime = WALK_TIME;
				this.startFrame = this.startIndex + 8;
				break;
			case this.animationStates["WALKING_D"]:
				this.numFrames = 6;
				this.animationTime = WALK_TIME;
				this.startFrame = this.startIndex + 15;
				break;
			case this.animationStates["PUNCH_U"]:
				this.numFrames = 5;
				this.animationTime = PUNCH_TIME;
				this.startFrame = this.startIndex + 34;
				break;
			case this.animationStates["PUNCH_R"]:
				this.numFrames = 3;
				this.animationTime = PUNCH_TIME;
				this.startFrame = this.startIndex + 31;
				break;
			case this.animationStates["PUNCH_L"]:
				this.numFrames = 3;
				this.animationTime = PUNCH_TIME;
				this.startFrame = this.startIndex + 28;
				break;
			case this.animationStates["PUNCH_D"]:
				this.numFrames = 5;
				this.animationTime = PUNCH_TIME;
				this.startFrame = this.startIndex + 39;
				break;
		}
		if (this.animationState == this.animationStates["IDLE"]){
			this.numFrames = 1;
			this.animationTime = 10000;
			
			switch (this.direction){
				case 0:
					this.startFrame = this.startIndex;
					break;
				case 1:
					this.startFrame = this.startIndex + 21;
					break;
				case 2:					
					this.startFrame = this.startIndex + 7;
					break;
				case 3:
					this.startFrame = this.startIndex + 14;
					break;
			}
		}
		
	}
	
	//move the attack box in the correct position
	updateAttackBox(){
		//update the attack box
		this.attackBox.active = false;
		if (this.takingDamage) return;
		
		if (this.punching){
			this.attackBox.active = true;
		}
		//set the position of the attack hitbox if the attack is active
		//whether the attack is active or not depends on the child class
		if(this.attackBox.active){
			if (this.direction == 0){
				this.attackBox.x = this.sprite.x + this.sprite.w;
				this.attackBox.y = this.sprite.y + this.sprite.h/2 - this.attackBox.h / 2;
			}
			else if (this.direction == 1){
				this.attackBox.x = this.sprite.x + this.sprite.w/2 - this.attackBox.w /2;
				this.attackBox.y = this.sprite.y - this.sprite.h/2;
			}
			else if (this.direction == 2){
				this.attackBox.x = this.sprite.x - this.sprite.w;
				this.attackBox.y = this.sprite.y + this.sprite.h/2 - this.attackBox.h / 2;
			}
			else if (this.direction == 3){
				this.attackBox.x = this.sprite.x + this.sprite.w/2 - this.attackBox.w /2;
				this.attackBox.y = this.sprite.y + this.sprite.h;
			}
			
		}
	}
	
	//update the damage timer and how long this entity is invulnerable
	updateDamage(){
		//update the damage timer
		this.damageTimer--;
		this.invulnerability--;
		
		if (this.damageTimer < 0){
			this.damageTimer = 0;
			this.takingDamage = false;
		}

		if (this.invulnerability <= 0){
			this.invulnerability = 0;
		}
	}

	//************************************************************
	// 			functions only being called from the child classes
	//************************************************************
	
	//take a hit
	takeDamage(attackPower){
		//cannot take more damage until the timer reaches 0
		if (this.damageTimer > 0 || this.invulnerability > 0)
			return;

		this.invulnerability = DAMAGE_COOLDOWN + INVULNERABILITY_TIME;
		this.takingDamage = true;
		this.damageTimer = DAMAGE_COOLDOWN;
		this.health -= attackPower;
		
		if (this.health <= 0){
			this.dead = true;
			this.health = 0;
		}
	}

	//take a bullet
	takeShot(attackPower){
		// the difference between takeShot and takeDamage is that takeShot can occur any time
		// while take damage can only occur if the timer is 0
		this.takingDamage = true;
		this.damageTimer = DAMAGE_COOLDOWN;
		this.health -= attackPower;
		
		if (this.health <= 0){
			this.dead = true;
			this.health = 0;
		}
	}

	checkForAttack(entities){
		//check for collision with another attack hitbox
		for (let i = 0; i < entities.length; i++){
			if (entities[i].attackBox.active && entities[i].attackBox.touching(this.sprite)){
				this.takeDamage(entities[i].attackDamage);
				//return whoever hits this entity
				return entities[i];
			}			
		}

		// return null if no hits were detected
		return null;
	}
	
	moveInDirection(xDist,yDist,flip,move = true){
		let absXDist = Math.abs(xDist);
		let absYDist = Math.abs(yDist);

		if (flip == 1){
			if(absXDist > absYDist){
				if (xDist < 0){
					this.direction = 2;
				}
				else{
					this.direction = 0;
				}
			}
			else{
				if (yDist < 0){
					this.direction = 1;
				}
				else{
					this.direction = 3;
				}
			}
		} else{
			if(absXDist > absYDist){
				if (xDist < 0){
					this.direction = 0;
				}
				else{
					this.direction = 2;
				}
			}
			else{
				if (yDist < 0){
					this.direction = 3;
				}
				else{
					this.direction = 1;
				}
			}
		}
		
		
		if (!move) return;

		this.walking = true;
		switch(this.direction){
			case 0:
				this.sprite.x += this.speed;
				break;
			case 1:
				this.sprite.y -= this.speed;
				break;
			case 2:
				this.sprite.x -= this.speed;
				break;
			default:
				this.sprite.y += this.speed;
		}
	}

	findNearest(entities){
		let closestEntity = null;
		let closestDistVec = [0,0];
		let closestDist = 90000000;
		
		for (let i = 0; i < entities.length; i++){
			let entity = entities[i];
			if (entity.dead)
				continue;
			
			let xDist = entity.sprite.x - this.sprite.x;
			let yDist = entity.sprite.y - this.sprite.y;

			//calculate the distance vector
			let distVec = [xDist,yDist];
			let dist = Math.sqrt(Math.pow(xDist,2) + Math.pow(yDist,2));

			if (dist < closestDist){
				closestEntity = entity;
				closestDist = dist;
				closestDistVec = distVec;
			}
		}

		return [closestEntity,closestDistVec,closestDist];
	}
}

module.exports = Entity;