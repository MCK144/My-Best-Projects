const LINE_WIDTH = "2";

class Renderer{
	constructor(){
		this.canvas = document.getElementsByTagName("canvas")[0];
		this.context = this.canvas.getContext("2d");
		this.images = document.getElementsByTagName("img");
		this.backgroundColor = "lightgray";

		this.context.fillStyle = this.backgroundColor;
		//this.context.lineWidth = LINE_WIDTH;
		
		this.staticData = [];
	}
	
	drawSprite(sprite,camera){
		//dc = draw coords, the translated position for drawing
		var dc = camera.translate(sprite.x,sprite.y);

		if (sprite.image == null){
			this.context.drawImage(this.images[sprite.textureID],
													 dc[0],dc[1],sprite.w,sprite.h);
		} else {
			this.context.drawImage(sprite.image,dc[0],dc[1],sprite.w,sprite.h);
		}
	}
	
	drawHitbox(hitbox,camera){
		var dc = camera.translate(hitbox.x,hitbox.y);
		this.context.fillStyle = hitbox.color; //for SOME reason I can't use the variable
		this.context.fillRect(dc[0],dc[1],hitbox.w,hitbox.h);
	}

	drawBullet(bullet,camera){
		var dc = camera.translate(bullet.x,bullet.y);
		this.context.fillStyle = "black";
		this.context.beginPath();
		this.context.arc(dc[0],dc[1],bullet.r,0,Math.PI * 2);
		this.context.fill();
	}
	
	drawStaticData(camera){
		for (let i = 0; i < this.staticData.length; i++){
			this.drawSprite(this.staticData[i],camera);
		}
	}

	drawPlayerInventory(player){
		let inventory = player.inventory;
		if (inventory.length == 0) return;
		
		const ITEM_W = 50;
		const ITEM_H = 50;
		const Y_POS = this.canvas.height - ITEM_H * 2;

		let inventoryWidth = inventory.length * ITEM_W;
		let inventoryHeight = ITEM_H;

		let startX = this.canvas.width / 2 - (ITEM_W/2 * inventory.length);
		let x = startX;

		//draw the box around the items
		this.context.beginPath();
		this.context.moveTo(startX,Y_POS);
		this.context.lineTo(startX + inventoryWidth,Y_POS);
		this.context.lineTo(startX + inventoryWidth,Y_POS + ITEM_H);
		this.context.lineTo(startX, Y_POS + ITEM_H);
		this.context.lineTo(startX,Y_POS);
		this.context.stroke();
		
		//draw each item
		for (let i = 0; i < inventory.length; i++){
			this.context.beginPath();
			this.context.strokeStyle = "black";
			this.context.drawImage(this.images[inventory[i].textureID], x, Y_POS,ITEM_W,ITEM_H);
			
			//draw the dividers between the items
			this.context.moveTo(x + ITEM_W, Y_POS);
			this.context.lineTo(x+ITEM_W, Y_POS + ITEM_H);
			this.context.stroke();

			//draw a yellow bar under the selected item
			if (player.selectedItem == i){
				const BAR_H = 2;
				this.context.fillStyle = "yellow";
				this.context.fillRect(x,Y_POS + ITEM_H,ITEM_W, BAR_H);
			}

			x += ITEM_H;

		}
	}

	drawGUI(player,numCitizens,numCriminals){
		const GUI_Y = this.canvas.height - 100;
		const GUI_X = 30;
		const padding = 10;
		const TEXT_HEIGHT = 30;
		
		this.context.font = "30pt sans";
		this.context.fillStyle = "darkblue";
		this.context.fillText("Health: " + player.health,GUI_X,GUI_Y);
		this.context.fillText("Citizens: " + numCitizens,GUI_X,GUI_Y + padding + TEXT_HEIGHT);
		this.context.fillText("Criminals: " + numCriminals,GUI_X,GUI_Y + padding* 2 + TEXT_HEIGHT * 2);

	}
	
	clear(){
		this.context.fillStyle = this.backgroundColor;
		this.context.fillRect(0,0,this.canvas.width,this.canvas.height);
	}

	getCanvas(){
		return this.canvas;
		//https://thewebdev.info/2022/04/30/how-to-get-real-mouse-position-in-canvas-with-javascript/#:~:text=To%20get%20real%20mouse%20position%20in%20canvas%20with%20JavaScript%2C%20we,return%20%7B%20x%3A%20((evt.
	}
}

export {Renderer};