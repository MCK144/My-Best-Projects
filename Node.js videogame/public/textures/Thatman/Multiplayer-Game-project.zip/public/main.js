import {Renderer} from "./renderer.js";
import {Camera} from "./Camera.js";

var socket = io.connect("https://multiplayer-game-project.mck144.repl.co/");

// renders all server data for teh client
var renderer = new Renderer;
// translates all positions relative to this client's player
var camera = new Camera;
// the client's key state to be processed by the server
var keys = {
	w:false,
	a:false,
	s:false,
	d:false,
	space:false,
	one: false,
	two: false,
	three: false,
	four: false
};

//used so that the client can calculate click positions
var canvas = renderer.getCanvas();
const cr = canvas.getBoundingClientRect(); //stands for canvas rect
// the player id for this client (to keep track of camera movement)
var playerIndex = 0;


//Server data:
//0- streets list 
//1- players list
socket.on("connect",function(){
	//set the player index so the client knows which player is its
	socket.on("getPlayerIndex",function(data){
		playerIndex = data;
	});

	socket.on("getStaticData",function(data){
		renderer.staticData = data;
	});

	socket.on("updatePlayerIndex",function(deletedPlayerIndex){
		if (playerIndex > deletedPlayerIndex){
			playerIndex--;
		}
	});
	
	//server update
	socket.on("serverUpdate",function(data){
		//clear the background
		renderer.clear();

		//update the camera
		camera.update(data[1][playerIndex].sprite);

		//draw streets
		renderer.drawStaticData(camera);

		//draw the citizens
		let numCitizens = data[0].length;
		for (let i = 0; i < data[0].length; i++){
			renderer.drawSprite(data[0][i].sprite,camera);
			if (data[0][i].attackBox.active){
				renderer.drawHitbox(data[0][i].attackBox,camera);
			}
			//for the GUI
			if (data[0][i].dead){
				numCitizens--;
			}
		}

		let numCriminals = data[4].length;
		//draw the criminals
		for (let i = 0; i < data[4].length; i++){
			renderer.drawSprite(data[4][i].sprite,camera);
			if (data[4][i].attackBox.active){
				renderer.drawHitbox(data[4][i].attackBox,camera);
			}
			if (data[4][i].dead){
				numCriminals--;
			}
		}
		
		//draw players
		for (let i = 0; i < data[1].length; i++){
			renderer.drawSprite(data[1][i].sprite,camera);
			if (data[1][i].attackBox.active){
				renderer.drawHitbox(data[1][i].attackBox,camera);
			}

			//draw the player GUI
			if (data[1][i].index == playerIndex){
				renderer.drawGUI(data[1][i],numCitizens,numCriminals);
				renderer.drawPlayerInventory(data[1][i]);
			}
		}

		//draw items
		for (let i = 0; i < data[2].length; i++){
			renderer.drawSprite(data[2][i],camera);
		}

		//draw bullets
		for (let i = 0; i < data[3].length; i++){
			renderer.drawBullet(data[3][i],camera);
		}
		
	});
});


window.addEventListener("keydown",function(event){
	let broadcast = false;
	let key = event.key;
	
	if (key == 'w'){
		keys['w'] = true;
		broadcast = true;
	}
	if (key == 'a'){
		keys['a'] = true;
		broadcast = true;
	}
	if (key == 's'){
		keys['s'] = true;
		broadcast = true;
	}
	if (key == 'd'){
		keys['d'] = true;
		broadcast = true;
	}
	if (key == ' '){
		keys['space'] = true;
		broadcast = true;
	}
	if (key == '1'){
		keys['one'] = true;
		broadcast = true;
	}
	if (key == '2'){
		keys['two'] = true;
		broadcast = true;
	}
	if (key == '3'){
		keys['three'] = true;
		broadcast = true;
	}
	if (key == '4'){
		keys['four'] = true;
		broadcast = true;
	}

	//broadcast the data back to the server only if 
	// a real key was pressed
	if (broadcast)
		socket.emit("keyUpdate",keys);
});

window.addEventListener("keyup",function(event){
	let broadcast = false;
	
	let key = event.key;
	if (key == 'w'){
		keys['w'] = false;
		broadcast = true;
	}
	if (key == 'a'){
		keys['a'] = false;
		broadcast = true;
	}
	if (key == 's'){
		keys['s'] = false;
		broadcast = true;
	}
	if (key == 'd'){
		keys['d'] = false;
		broadcast = true;
	}
	if (key == ' '){
		keys['space'] = false;
		broadcast = true;
	}
	if (key == '1'){
		keys['one'] = false;
		broadcast = true;
	}
	if (key == '2'){
		keys['two'] = false;
		broadcast = true;
	}
	if (key == '3'){
		keys['three'] = false;
		broadcast = true;
	}
	if (key == '4'){
		keys['four'] = false;
		broadcast = true;
	}

	if (broadcast)
		socket.emit("keyUpdate",keys);
});

window.addEventListener("click",function(event){
	let data = [0,0];
	
	//calculate the click position
	data[0] = ((event.clientX - cr.left) / (cr.right - cr.left)) * canvas.width;
	data[1] = ((event.clientY - cr.top) / (cr.bottom - cr.top)) * canvas.height;

	//subtract the dimensions of the canvas
	data[0] -= canvas.width / 2;
	data[1] -= canvas.height / 2;

	//the server will handle adding back the player's position


	socket.emit("playerClick",data);

});